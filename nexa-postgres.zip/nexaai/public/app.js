const $ = (id) => document.getElementById(id);

const ADMIN_WA = "6285769438509";
const GREETING = "Halo! Gue Nexa. Mau ngobrolin apa hari ini?";

let mode = "login";        // "login" atau "register"
let currentConvId = null;  // percakapan yang sedang dibuka (null = chat baru)
let sending = false;

// Tambahan gaya untuk daftar riwayat di sidebar
const extraStyle = document.createElement("style");
extraStyle.textContent = `
  .item { display: flex; align-items: center; justify-content: space-between; gap: 8px; cursor: pointer; }
  .item .t { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .item.active { background: var(--line); color: var(--text); }
  .item .del { background: none; border: 0; color: var(--muted); cursor: pointer; font-size: 18px; line-height: 1; padding: 0 4px; }
  .item .del:hover { color: #ff6b7a; }
`;
document.head.appendChild(extraStyle);

// Kirim data ke server
async function api(url, body, method) {
  const res = await fetch(url, {
    method: method || (body ? "POST" : "GET"),
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Terjadi kesalahan.");
  return data;
}

function showChat() {
  $("authView").classList.add("hidden");
  $("chatView").classList.remove("hidden");
}

function showAuth() {
  $("chatView").classList.add("hidden");
  $("authView").classList.remove("hidden");
  $("authForm").reset();
  $("authMsg").textContent = "";
  clearHistoryList(); // jangan sisakan riwayat akun sebelumnya di layar
}

// ---------- RIWAYAT DI SIDEBAR ----------
function clearHistoryList() {
  document.querySelectorAll(".history .item").forEach((el) => el.remove());
}

async function loadConversations() {
  const box = document.querySelector(".history");
  let list = [];
  try {
    list = await api("/api/conversations");
  } catch (err) {
    clearHistoryList();
    return;
  }

  clearHistoryList();

  if (list.length === 0) {
    const empty = document.createElement("div");
    empty.className = "item";
    empty.style.cursor = "default";
    empty.textContent = "Belum ada percakapan";
    box.appendChild(empty);
    return;
  }

  list.forEach((c) => {
    const item = document.createElement("div");
    item.className = "item" + (c.id === currentConvId ? " active" : "");

    const title = document.createElement("span");
    title.className = "t";
    title.textContent = c.title;

    const del = document.createElement("button");
    del.className = "del";
    del.type = "button";
    del.title = "Hapus";
    del.textContent = "×";
    del.onclick = (e) => {
      e.stopPropagation();
      deleteConversation(c.id);
    };

    item.onclick = () => openConversation(c.id);
    item.appendChild(title);
    item.appendChild(del);
    box.appendChild(item);
  });
}

function startNewChat() {
  currentConvId = null;
  $("messages").innerHTML = "";
  addBubble(GREETING, "ai");
  loadConversations();
}

async function openConversation(id) {
  if (sending) return;
  try {
    const data = await api("/api/conversations/" + id + "/messages");
    currentConvId = id;
    $("messages").innerHTML = "";
    data.messages.forEach((m) => addBubble(m.content, m.role === "user" ? "user" : "ai"));
    $("sidebar").classList.remove("open");
    loadConversations();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteConversation(id) {
  if (sending) return;
  if (!confirm("Hapus percakapan ini?")) return;
  try {
    await api("/api/conversations/" + id, null, "DELETE");
    if (id === currentConvId) startNewChat();
    else loadConversations();
  } catch (err) {
    alert(err.message);
  }
}

// ---------- LOGIN / DAFTAR ----------
function setMode(newMode) {
  mode = newMode;
  $("tabLogin").classList.toggle("active", mode === "login");
  $("tabRegister").classList.toggle("active", mode === "register");
  $("authBtn").textContent = mode === "login" ? "Masuk" : "Daftar";
  $("authMsg").textContent = "";
}
$("tabLogin").onclick = () => setMode("login");
$("tabRegister").onclick = () => setMode("register");

// Lupa password -> link WhatsApp admin
$("forgot").onclick = (e) => {
  e.preventDefault();
  const pesan = encodeURIComponent("Halo admin Nexa AI, saya lupa password akun saya.");
  $("authMsg").className = "msg ok";
  $("authMsg").innerHTML =
    'Lupa password? <a href="https://wa.me/' + ADMIN_WA + "?text=" + pesan +
    '" target="_blank" style="color:#19e3ff">Hubungi admin via WhatsApp</a>';
};

$("authForm").onsubmit = async (e) => {
  e.preventDefault();
  const url = mode === "login" ? "/api/login" : "/api/register";
  $("authMsg").className = "msg";
  $("authMsg").textContent = "";
  $("authBtn").disabled = true;

  try {
    await api(url, {
      username: $("username").value,
      password: $("password").value,
    });
    $("authForm").reset();
    startNewChat();
    showChat();
  } catch (err) {
    $("authMsg").textContent = err.message;
  } finally {
    $("authBtn").disabled = false;
  }
};

$("logoutBtn").onclick = async () => {
  try {
    await api("/api/logout", {});
  } catch (err) {}
  currentConvId = null;
  $("messages").innerHTML = "";
  addBubble(GREETING, "ai");
  showAuth();
};

// Menu sidebar di HP
$("menuBtn").onclick = () => $("sidebar").classList.toggle("open");

// ---------- CHAT ----------
function addBubble(text, who) {
  const div = document.createElement("div");
  div.className = "bubble " + who;
  div.style.whiteSpace = "pre-wrap";
  div.textContent = text;
  $("messages").appendChild(div);
  $("messages").scrollTop = $("messages").scrollHeight;
  return div;
}

function setSending(value) {
  sending = value;
  $("chatInput").disabled = value;
  $("chatForm").querySelector("button").disabled = value;
  if (!value) $("chatInput").focus();
}

$("chatForm").onsubmit = async (e) => {
  e.preventDefault();
  const text = $("chatInput").value.trim();
  if (!text || sending) return;

  $("chatInput").value = "";
  addBubble(text, "user");
  const bubble = addBubble("Nexa lagi mengetik...", "ai");
  setSending(true);

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ conversationId: currentConvId, message: text }),
    });

    if (res.status === 401) {
      showAuth();
      return;
    }
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || "Terjadi kesalahan.");
    }

    // Server memberi tahu id percakapan (penting untuk chat baru)
    const newId = Number(res.headers.get("X-Conversation-Id"));
    if (newId) currentConvId = newId;

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let full = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      full += decoder.decode(value, { stream: true });
      bubble.textContent = full;
      $("messages").scrollTop = $("messages").scrollHeight;
    }
    loadConversations();
  } catch (err) {
    bubble.textContent = err.message;
  } finally {
    setSending(false);
  }
};

$("newChat").onclick = () => {
  if (sending) return;
  startNewChat();
  $("sidebar").classList.remove("open");
};

// Saat halaman dibuka: kalau masih login, langsung ke chat
api("/api/me")
  .then(() => {
    startNewChat();
    showChat();
  })
  .catch(() => {});